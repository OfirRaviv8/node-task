#!/bin/bash
echo "Hello from main.sh inside Docker!"
